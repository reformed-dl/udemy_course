use fitness::GymWorkout;

fn main() {
    let workout = GymWorkout::new();
    println!("{:#?}", workout);
}
